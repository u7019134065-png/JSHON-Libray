# .jshon LIB
- Что такое .jshon LIB
- Установка и структура
- Как добавить зависимость
- Как писать мод на русском
- Категории и примеры:
  * items
  * liquids
  * blocks
  * units
  * effects
  * planets
  * sectors
  * tech
  * logic commands
- Как работает трансляция
- Как собрать проект на телефоне (через Termux или проводник)
- Как загрузить на GitHub
- FAQ и ошибки